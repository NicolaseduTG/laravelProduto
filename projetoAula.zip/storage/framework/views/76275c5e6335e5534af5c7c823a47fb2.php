<?php $__env->startSection('conteudo'); ?>

<div class="container">
    <h1>Lista de Usuarios</h1>
    <div class="table-responsive">
        <a class="btn btn-success" href="<?php echo e(route('usuarios.cadastro')); ?>">Adicionar</a>


        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Nome</th>
                    <th>Login</th>
                    <th>Senha</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($usuario->id); ?> </td>
                    <td><?php echo e($usuario->nome); ?></td>
                    <td><?php echo e($usuario->login); ?></td>
                    <td><?php echo e($usuario->senha); ?></td>
                    <td>
                        <a class="btn btn-primary" href="<?php echo e(route('usuario.atualiza', ['id' => $usuario->id])); ?>" >Alterar</a>
                        <button class="btn btn-danger" onclick="excluir(<?php echo e($usuario->id); ?>)" >Excluir</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>
</div>

<script>
    function excluir(id){ 
        if (confirm(`Deseja excluir o usuário de id '${id}'?`)) {
            location.href = '/usuarios/excluir/' + id;
        }
    }
</script>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WebDocuments\projetoAula\resources\views/usuarios/index.blade.php ENDPATH**/ ?>