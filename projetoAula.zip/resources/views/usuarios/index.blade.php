@extends('layouts.app')
@section('conteudo')

<div class="container">
    <h1>Lista de Usuarios</h1>
    <div class="table-responsive">
        <a class="btn btn-success" href="{{route('usuarios.cadastro')}}">Adicionar</a>


        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Nome</th>
                    <th>Login</th>
                    <th>Senha</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($usuarios as $usuario)
                <tr>
                    <td> {{ $usuario->id }} </td>
                    <td>{{ $usuario->nome }}</td>
                    <td>{{ $usuario->login }}</td>
                    <td>{{ $usuario->senha }}</td>
                    <td>
                        <a class="btn btn-primary" href="{{route('usuario.atualiza', ['id' => $usuario->id])}}" >Alterar</a>
                        <button class="btn btn-danger" onclick="excluir({{$usuario->id}})" >Excluir</a>
                    </td>
                </tr>
                @endforeach

            </tbody>
        </table>
    </div>
</div>

<script>
    function excluir(id){ 
        if (confirm(`Deseja excluir o usuário de id '${id}'?`)) {
            location.href = '/usuarios/excluir/' + id;
        }
    }
</script>